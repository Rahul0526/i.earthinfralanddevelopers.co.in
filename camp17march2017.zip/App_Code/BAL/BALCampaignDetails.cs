﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BALCampaignDetails
/// </summary>
public class BALCampaignDetails
{
	public BALCampaignDetails()
	{
		
	}
    public string _Action { get; set; }
    public string _bannerType { get; set; }
    public string _Banner { get; set; }
    public string _CampId { get; set; }
    public string _WebSiteName { get; set; }

    //public string _Action { get; set; }
    //public string _Action { get; set; }
    //public string _Action { get; set; }
    //public string _Action { get; set; }
}