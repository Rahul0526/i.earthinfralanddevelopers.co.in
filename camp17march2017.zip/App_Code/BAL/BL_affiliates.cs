﻿using System;
using System.Collections.Generic;

using System.Web;

/// <summary>
/// Summary description for BL_affiliates
/// </summary>
public class BL_affiliates
{


    public string action { get; set; }

    public string aff_id { get; set; }
    public string aff_name { get; set; }

    public string mail { get; set; }
    public string age { get; set; }
    public string bank_info { get; set; }
    public string acc { get; set; }
    public string payment { get; set; }
    public string website { get; set; }
    public string address { get; set; }
    public DateTime date { get; set; }



	public BL_affiliates()
	{
		
	}
}